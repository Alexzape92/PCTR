
public class critico {
	int n;
	
	public critico() {
		n = 0;
	}
	
	public void inc() {
		n++;
	}
	
	public void dec() {
		n--;
	}
	
	public void show() {
		System.out.println(n);
	}
}
